<?php
$servername="localhost";
$username="root";
$password="";
$dbname="sample";

$conn= new mysqli($servername,$username,$password,$dbname);
if($conn->connect_error)
{
die("connection failed");
}
else
{
echo "Connected Sucessfully";
}
?>
